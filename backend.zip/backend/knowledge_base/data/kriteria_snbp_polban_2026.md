# Kriteria Penilaian Prestasi & Persyaratan Jurusan SNBP 2026 — Politeknik Negeri Bandung (POLBAN)

Dokumen ini adalah basis pengetahuan (knowledge base) resmi yang digunakan mesin audit kepatuhan untuk memverifikasi sertifikat prestasi dan kelayakan jurusan asal sekolah pendaftar SNBP 2026 di Politeknik Negeri Bandung (POLBAN). Sumber data: berkas resmi "Data Lengkap Prodi SNBP 2026".

## Aturan Umum Pembobotan

- Komponen penilaian terdiri dari Mata Pelajaran Pendukung 1 (MP1), Mata Pelajaran Pendukung 2 (MP2), dan komponen Prestasi.
- Total bobot MP1 + MP2 + Prestasi maksimum adalah 50%.
- Nilai "Bobot komponen prestasi" pada setiap program studi menunjukkan besarnya bobot prestasi (dalam persen) yang diperhitungkan untuk program studi tersebut.
- Prestasi yang diakui dikelompokkan menjadi tingkat: Internasional, Nasional, Kabupaten/Kota, dan Lokal. Hanya jenis lomba/kompetisi yang tercantum pada setiap program studi yang diakui.
- Pendaftar wajib berasal dari jurusan SMA/MA/SMK yang diizinkan oleh program studi tujuan. Jika program studi tidak mengizinkan semua jurusan SMK/MAK, hanya rumpun/jurusan SMK yang tercantum yang diperbolehkan.

## Glosarium Singkatan Lomba dan Kompetisi

### Olimpiade Internasional
- IMO — International Mathematical Olympiad (Matematika)
- IPhO — International Physics Olympiad (Fisika)
- IChO — International Chemistry Olympiad (Kimia)
- IBO — International Biology Olympiad (Biologi)
- IPO — International Philosophy Olympiad (Filsafat)
- IAO — International Astronomy Olympiad (Astronomi)
- IGO — International Geography Olympiad (Geografi)
- IOL — International Linguistics Olympiad (Linguistik)
- IOI — International Olympiad in Informatics (Informatika)
- IJSO — International Junior Science Olympiad (Sains Junior)
- IESO — International Earth Science Olympiad (Ilmu Kebumian)
- IOAA — International Olympiad on Astronomy and Astrophysics (Astronomi & Astrofisika)
- IHO — International History Olympiad (Sejarah)
- IEO — International Economics Olympiad / International English Olympiad (sesuai konteks: Ekonomi atau Bahasa Inggris)
- NEC — National English Competition (Bahasa Inggris)
- SEA GAMES — Southeast Asian Games (olahraga tingkat Asia Tenggara)

### Lomba Tingkat Nasional
- OSN — Olimpiade Sains Nasional
- OPSI — Olimpiade Penelitian Siswa Indonesia
- O2SN — Olimpiade Olahraga Siswa Nasional
- FLS2N — Festival dan Lomba Seni Siswa Nasional
- FLSI — Festival Literasi Siswa Indonesia
- FIKSI — Festival Inovasi dan Kewirausahaan Siswa Indonesia
- LDBI — Lomba Debat Bahasa Indonesia
- NSDC — National Schools Debating Championship
- LKS — Lomba Kompetensi Siswa
- LKIR — Lomba Karya Ilmiah Remaja
- PON — Pekan Olahraga Nasional
- PORSENI — Pekan Olahraga dan Seni

---

# Program Diploma 3 (D3)

## Teknik Konstruksi Gedung — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Sipil
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota, Lokal
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Geography Olympiad (IGO), International Earth Science Olympiad (IESO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Festival dan Lomba Seni Siswa Nasional
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknologi Konstruksi dan Properti, Teknik Geomatika dan Geospasial
    - Rumpun Energi dan Pertambangan: Geologi Pertambangan

## Teknik Konstruksi Sipil — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Sipil
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Junior Science Olympiad (IJSO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknologi Konstruksi dan Properti, Teknik Geomatika dan Geospasial

## Teknik Mesin — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Mesin
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Earth Science Olympiad (IESO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Inovasi dan Kewirausahaan Siswa Indonesia, National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Ilmu Kebumian, Organisasi Ekstrakurikuler/Pramuka
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Mesin, Teknologi Pesawat Udara, Teknik Otomotif, Teknik Perkapalan
    - Rumpun Energi dan Pertambangan: Teknik Energi Terbarukan

## Teknik Aeronautika — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Mesin
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Olympiad in Informatics (IOI)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknik Otomotif
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Teknik Pendingin dan Tata Udara — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Refrigerasi dan Tata Udara
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota, Lokal
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR), Lomba Kompetensi Siswa (LKS)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknik Instrumentasi Industri, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Teknik Konversi Energi — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Konversi Energi
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia, Olimpiade Biologi, Olimpiade Ilmu Kebumian, Olimpiade Ekonomi, Olimpiade Geografi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknologi Pesawat Udara, Teknik Grafika, Teknik Instrumentasi Industri, Teknik Industri, Teknologi Tekstil, Teknik Kimia, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Perminyakan, Geologi Pertambangan, Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi
    - Rumpun Agribisnis dan Agroteknologi: Teknik Pertanian
    - Rumpun Kemaritiman: Pengolahan Hasil Perikanan

## Teknik Listrik — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia, Olimpiade Biologi, Olimpiade Ilmu Kebumian, Olimpiade Ekonomi, Olimpiade Geografi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknologi Konstruksi dan Properti, Teknik Ketenagalistrikan, Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknik Kimia, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi

## Teknik Elektronika — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Astronomy Olympiad (IAO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), SEA GAMES, International Robotics/Electronics Competition
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR), Lomba Robotik/Elektronika Tingkat Nasional
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknik Instrumentasi Industri, Teknik Otomotif, Teknik Elektronika
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi

## Teknik Telekomunikasi — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Elektronika
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi

## Teknik Kimia — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Kimia
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Pekan Olahraga Nasional (PON), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia, Olimpiade Biologi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Analis Kimia — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Kimia
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Olympiad in Informatics (IOI), International Earth Science Olympiad (IESO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Kimia
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Industri, Teknologi Tekstil, Teknik Kimia
    - Rumpun Energi dan Pertambangan: Teknik Perminyakan, Geologi Pertambangan, Teknik Energi Terbarukan
    - Rumpun Kesehatan dan Pekerjaan Sosial: Teknologi Laboratorium Medik, Farmasi
    - Rumpun Agribisnis dan Agroteknologi: Agribisnis Pengolahan Hasil Pertanian, Teknik Pertanian
    - Rumpun Kemaritiman: Pengolahan Hasil Perikanan

## Teknik Informatika — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Teknik Komputer dan Informatika
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), Lomba Kompetensi Siswa Nasional, Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Akuntansi — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Akuntansi
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Ekonomi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Keuangan dan Perbankan — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Akuntansi
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Olimpiade Matematika, Olimpiade Ekonomi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Administrasi Bisnis — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa, SMA Agama/Teologi
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Usaha Perjalanan Wisata — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Linguistics Olympiad (IOL), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival Literasi Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Manajemen Pemasaran — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES, Tingkat internasional lainnya
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR), Tingkat internasional lainnya
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa, SMA Agama/Teologi
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Bahasa Inggris — Program Diploma 3 (D3)
- **Jurusan/Departemen:** Bahasa Inggris
- **Program:** Program Diploma 3 (D3)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International English Olympiad (IEO), National English Competition (NEC)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia, Olimpiade Biologi, Olimpiade Ilmu Kebumian, Olimpiade Ekonomi, Olimpiade Geografi, Organisasi Ekstrakurikuler/Pramuka
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa
- **Mengizinkan semua jurusan SMK/MAK?** Ya

# Program Sarjana Terapan (D4)

## Teknik Perancangan Jalan dan Jembatan — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Sipil
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Lomba Kompetensi Siswa Nasional
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknologi Konstruksi dan Properti

## Teknik Perawatan dan Perbaikan Gedung — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Sipil
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknologi Konstruksi dan Properti

## Teknik Perancangan dan Konstruksi Mesin — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Mesin
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Perminyakan, Geologi Pertambangan, Teknik Energi Terbarukan
    - Rumpun Agribisnis dan Agroteknologi: Teknik Pertanian

## Proses Manufaktur — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Mesin
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota, Lokal
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Festival Literasi Siswa Indonesia, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknik Otomotif, Teknik Elektronika

## Teknik Pendingin dan Tata Udara — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Refrigerasi dan Tata Udara
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota, Lokal
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Chemistry Olympiad (IChO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR), Lomba Kompetensi Siswa (LKS) bidang refrigerasi dan tata udara, elektronika, atau kelistrikan
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknik Instrumentasi Industri, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Teknologi Pembangkit Tenaga Listrik — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Konversi Energi
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknologi Tekstil, Teknik Kimia, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Perminyakan, Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi
    - Rumpun Kesehatan dan Pekerjaan Sosial: Teknologi Laboratorium Medik

## Teknik Konservasi Energi — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Konversi Energi
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, National Schools Debating Championship (NSDC), Pekan Olahraga Nasional (PON), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Keagamaan, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Mesin, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknologi Tekstil, Teknik Kimia, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Perminyakan, Geologi Pertambangan, Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika
    - Rumpun Seni dan Industri Kreatif: Seni Musik

## Teknik Telekomunikasi — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknologi Pesawat Udara, Teknik Instrumentasi Industri, Teknik Industri, Teknik Otomotif, Teknik Perkapalan, Teknik Elektronika
    - Rumpun Energi dan Pertambangan: Teknik Energi Terbarukan
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi

## Teknik Elektronika — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Junior Science Olympiad (IJSO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Pekan Olahraga Nasional (PON)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Instrumentasi Industri, Teknik Elektronika
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika, Teknik Telekomunikasi

## Teknik Otomasi Industri — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Elektro
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Olympiad on Astronomy and Astrophysics (IOAA)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Fisika
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Ketenagalistrikan, Teknik Instrumentasi Industri, Teknik Elektronika
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Teknik Kimia Produksi Bersih — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Kimia
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 5
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA
- **Jurusan MA yang diizinkan mendaftar:** MA IPA
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi dan Rekayasa: Teknik Industri, Teknik Kimia

## Teknik Informatika — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Teknik Komputer dan Informatika
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO)
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), Lomba Kompetensi Siswa Nasional, Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Teknologi Informasi dan Komunikasi: Teknik Komputer dan Informatika

## Akuntansi Manajemen Pemerintahan — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Akuntansi
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Economics Olympiad (IEO), SEA GAMES, International Accounting Competition
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Olahraga Siswa Nasional, Festival Inovasi dan Kewirausahaan Siswa Indonesia, National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Olimpiade Ekonomi, Organisasi Ekstrakurikuler/Pramuka, Olimpiade akuntansi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Bisnis dan Manajemen: Manajemen Perkantoran, Akuntansi dan Keuangan

## Keuangan Syariah — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Akuntansi
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Ekonomi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa, SMA Agama/Teologi
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Akuntansi — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Akuntansi
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa
- **Mengizinkan semua jurusan SMK/MAK?** Tidak
- **Jurusan SMK/MAK yang diizinkan (per rumpun):**
    - Rumpun Bisnis dan Manajemen: Bisnis dan Pemasaran, Manajemen Perkantoran, Akuntansi dan Keuangan

## Administrasi Bisnis — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Economics Olympiad (IEO)
- **Prestasi Tingkat Nasional yang diakui:** Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Ekonomi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Manajemen Aset — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Junior Science Olympiad (IJSO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olimpiade Matematika, Olimpiade Ekonomi
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa, SMA Agama/Teologi
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Manajemen Pemasaran — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional, Kabupaten/Kota, Lokal
- **Bobot komponen prestasi (persen):** 10
- **Prestasi Tingkat Internasional yang diakui:** International Mathematical Olympiad (IMO), International Physics Olympiad (IPhO), International Chemistry Olympiad (IChO), International Biology Olympiad (IBO), International Philosophy Olympiad (IPO), International Astronomy Olympiad (IAO), International Geography Olympiad (IGO), International Linguistics Olympiad (IOL), International Olympiad in Informatics (IOI), International Junior Science Olympiad (IJSO), International Earth Science Olympiad (IESO), International Olympiad on Astronomy and Astrophysics (IOAA), International History Olympiad (IHO), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Olahraga, Seni, Keagamaan, Olimpiade Matematika, Olimpiade Fisika, Olimpiade Kimia, Olimpiade Biologi, Olimpiade Ilmu Kebumian, Olimpiade Ekonomi, Olimpiade Geografi, Organisasi Ekstrakurikuler/Pramuka
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa, SMA Agama/Teologi
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa, MA Agama
- **Mengizinkan semua jurusan SMK/MAK?** Ya

## Destinasi Pariwisata — Program Sarjana Terapan (D4)
- **Jurusan/Departemen:** Administrasi Niaga
- **Program:** Program Sarjana Terapan (D4)
- **Kategori prestasi yang diakui:** Internasional, Nasional
- **Bobot komponen prestasi (persen):** 20
- **Prestasi Tingkat Internasional yang diakui:** International Linguistics Olympiad (IOL), International Economics Olympiad (IEO), SEA GAMES
- **Prestasi Tingkat Nasional yang diakui:** Olimpiade Sains Nasional (OSN), Olimpiade Penelitian Siswa Indonesia (OPSI), Olimpiade Olahraga Siswa Nasional, Festival dan Lomba Seni Siswa Nasional, Festival Literasi Siswa Indonesia, Festival Inovasi dan Kewirausahaan Siswa Indonesia, Lomba Debat Bahasa Indonesia (LDBI), National Schools Debating Championship (NSDC), Lomba Kompetensi Siswa Nasional, Pekan Olahraga Nasional (PON), Pekan Olahraga dan Seni (PORSENI), Lomba Karya Ilmiah Remaja (LKIR)
- **Prestasi Tingkat Kabupaten/Kota yang diakui:** Tidak dispesifikkan
- **Jurusan SMA yang diizinkan mendaftar:** SMA IPA, SMA IPS, SMA Bahasa
- **Jurusan MA yang diizinkan mendaftar:** MA IPA, MA IPS, MA Bahasa
- **Mengizinkan semua jurusan SMK/MAK?** Ya
